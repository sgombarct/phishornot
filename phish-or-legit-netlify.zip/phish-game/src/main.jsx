import React from 'react'
import ReactDOM from 'react-dom/client'
import PhishOrLegit from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PhishOrLegit />
  </React.StrictMode>,
)
